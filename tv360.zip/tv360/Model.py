from langchain_openai import ChatOpenAI

base_path = 'http://localai:8080/v1'
model_name = 'gemma-2-9b-it'
key = '-'

model = ChatOpenAI(temperature=0, openai_api_base=base_path, openai_api_key=key, model_name=model_name, max_tokens=100)

# Example for fewshot
queries_ex = """
# 1. Tìm tất cả các phim thuộc thể loại "kiếm hiệp"
{
  "query": {
    "match": {
      "summary": "kiếm hiệp"
    }
  }
}

# 2. Tìm tất cả các tài liệu có tiêu đề chứa từ "Doraemon"
{
  "query": {
    "match": {
      "title": "Doraemon"
    }
  }
}

# 3. Tìm tất cả các tài liệu có tiêu đề chứa từ "Deadpool"
{
  "query": {
    "match": {
      "title": "Deadpool"
    }
  }
}

# 4. Tìm tất cả các tài liệu có từ khóa "phim hot"
{
  "query": {
    "match_all": {}
  },
  "sort": [
    {
      "view_count": {
        "order": "desc"
      }
    }
  ]
}

# 5. Tìm tất cả các phim với số lượt xem nhiều nhất (giả sử số lượng là 50000)
{
  "query": {
    "range": {
      "view_count": {
        "gte": 50000
      }
    }
  }
}

# 6. Tìm tất cả các tài liệu có từ khóa "action" và sử dụng KNN cho tìm kiếm semantic
{
  "query": {
    "match": {
      "summary": "action"
    }
  },
  "knn": {
    "context": "action"
  }
}

# 7. Tìm tất cả các phim với từ khóa "phim hài" và sử dụng KNN cho tìm kiếm semantic
{
  "query": {
    "match": {
      "summary": "phim hài"
    }
  },
  "knn": {
    "context": "phim hài"
  }
}

# 8. Tìm tất cả các phim có từ khóa "superhero" và sử dụng KNN cho tìm kiếm semantic
{
  "query": {
    "match": {
      "summary": "superhero"
    }
  },
  "knn": {
    "context": "superhero"
  }
}

# 9. Tìm tất cả các tài liệu có từ khóa "tình cảm" và sử dụng KNN cho tìm kiếm semantic
{
  "query": {
    "match": {
      "summary": "tình cảm"
    }
  },
  "knn": {
    "context": "tình cảm"
  }
}

# 10. Tìm tất cả các tài liệu có từ khóa "khoa học viễn tưởng" và sử dụng KNN cho tìm kiếm semantic
{
  "query": {
    "match": {
      "summary": "khoa học viễn tưởng"
    }
  },
  "knn": {
    "context": "khoa học viễn tưởng"
  }
}

"""

fields_ex = """
 1   type         , type: str, mô tả: loại item, có ba loại đó là: "moive", "channel", "video"
 2   title        , type: str, mô tả: tiêu để của item, nó có thể là: tiêu đề phim, tên kênh, tiêu đề video
 3   view_count   , type: int, mô tả: số lượng lượt xem
 4   duration     , type: float, mô tả: thời lượng của tập phim hoặc video
 5   summary      , type: str, mô tả: mô tả đầy đủ tổng quan về item
"""

system = f"""
    Bạn là một trợ lý tìm kiếm và gợi ý phim, kênh, video tiếng việt, dựa trên câu truy vấn của user, 
    bạn hãy viết một câu truy vấn DSL vào trong elasticsearch để tìm item phù hợp với user.
    Dưới đây là một số ví dụ về câu truy vấn của user và câu truy vấn DSL tương ứng vào elasticsearch 
    để tìm item phù hợp cho người dùng:
    {queries_ex}

    Hãy để ý cú pháp của câu truy vấn, nó phải chính xác, không thừa, không thiếu dẫu ngoặc.

    Đây là các trường thông tin để bạn dùng cho câu truy vấn:
    {fields_ex}

    Bạn phải sử dụng đúng các từ khóa ở trên, nếu bạn viết sai từ khóa, câu truy vấn sẽ không chạy

    Câu trả lời của bạn chỉ bao gồm câu truy vấn DSL, người dùng có thể nhập sai chính tả, nhập tiếng việt
    không có dấu, bạn hãy bạn hãy sửa lại chính tả và xem ý định của người dùng là gì rối mới tạo câu truy
    vấn DSL cho phù hợp.  
"""