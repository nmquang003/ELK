from pprint import pprint
from elasticsearch import Elasticsearch
from tqdm import tqdm
import requests
import json

class Search:
    def __init__(self, index_name = 'index01'):
        self.es = Elasticsearch('http://es:9200', request_timeout=300, max_retries=2, retry_on_timeout=True)  # <-- connection options need to be added here
        self.index_name = index_name
        client_info = self.es.info()
        print('Connected to Elasticsearch!')
        pprint(client_info.body)

    def create_index(self):
        self.es.indices.delete(index=self.index_name, ignore_unavailable=True)
        self.es.indices.create(index=self.index_name, mappings={
            'properties': {
                'embedding': {
                    'type': 'dense_vector',
                },
            }
        })

    def get_embedding(self, text, model="all-MiniLM-L6-v2", url="http://localai:8080/embeddings"):
        headers = {"Content-Type": "application/json"}
        data = {
            "input": text,
            "model": model
        }
        
        response = requests.post(url, headers=headers, data=json.dumps(data))
        
        if response.status_code == 200:
            return response.json()['data']  # Returns the JSON response as a Python dictionary
        else:
            response.raise_for_status()  # Raises an HTTPError if the HTTP request returned an unsuccessful status code
    
    def get_embeddings(self, texts, model="all-MiniLM-L6-v2", url="http://localai:8080/embeddings"):
        headers = {"Content-Type": "application/json"}
        data = {
            "input": texts,
            "model": model
        }
        
        response = requests.post(url, headers=headers, data=json.dumps(data))
        
        if response.status_code == 200:
            return response.json()['data']  # Returns the JSON response as a Python dictionary
        else:
            response.raise_for_status()  # Raises an HTTPError if the HTTP request returned an unsuccessful status code


    def insert_document(self, document):
        return self.es.index(index=self.index_name, document={
            **document,
            'embedding': self.get_embedding(document['summary'])[0]['embedding'],
        })

    def insert_documents(self, documents, chunk_size=100):
    # Chia nhỏ documents thành các chunk
        for i in tqdm(range(0, len(documents), chunk_size), desc="Inserting documents"):
            chunk = documents[i:i + chunk_size]
            
            # Gọi nhúng một lần cho mỗi chunk
            summaries = [doc['summary'] for doc in chunk]
            embeddings = self.get_embeddings(summaries)
            
            operations = []
            for doc, embedding in zip(chunk, embeddings):
                operations.append({'index': {'_index': self.index_name}})
                operations.append({
                    **doc,
                    'embedding': embedding['embedding'],
                })
        
            # Insert chunk vào Elasticsearch
            self.es.bulk(operations=operations)

    def reindex(self, filejson, chunk_size=100):
        self.create_index()
        with open(filejson, 'rt') as f:
            documents = json.loads(f.read())
        return self.insert_documents(documents, chunk_size=chunk_size)
    
    def search(self, query_args):
        return self.es.search(index=self.index_name, body=query_args)

    def retrieve_document(self, id):
        return self.es.get(index=self.index_name, id=id)
    
def extract_dsl_queries(input_string):
    queries = []
    stack = []
    start = -1

    for i, char in enumerate(input_string):
        if char == '{':
            if not stack:
                start = i  # Ghi nhớ vị trí bắt đầu của dấu ngoặc mở đầu tiên
            stack.append(char)  # Thêm dấu ngoặc mở vào stack

        elif char == '}':
            stack.pop()  # Loại bỏ một dấu ngoặc mở khỏi stack
            if not stack:
                queries.append(input_string[start:i+1])  # Thêm toàn bộ câu truy vấn vào danh sách

    res = []
    for query in queries:
        if 'query' not in query and 'knn' not in 'query':
            continue
        res.append(query)

    return res