import sys
import pandas as pd
import numpy as np
from tqdm import tqdm
from Search import Search, extract_dsl_queries
from Model import model, system

index_name = 'tv360'

es = Search(index_name)

# Kiểm tra index có tồn tại không
if es.es.indices.exists(index=index_name):
    if es.es.count(index=index_name)['count'] == 0:
        es.reindex('tv360_1000.json ')
        print('Index created, number of documents: ', es.es.count(index=index_name)['count'])
    else:
        print(f"Index '{index_name}' exist.")
else:
    es.reindex('data/tv360_1000.json ')
    print('Index created, number of documents: ', es.es.count(index=index_name)['count'])


def search_item(args:str, n_candidate = 10)->list: 
    """
    Searches for item documents (movie, channel, video) in Elasticsearch using the provided args.
    This function sends a search args to Elasticsearch and returns matching item documents.

    Parameters:
    - args (str): The search args formatted as a json. It can include fields like 'match', 'term', or 'bool' for specifying search criteria. It must be a string.

    Returns:
    - List[dict]: A list of search results from Elasticsearch. Each result is a dictionary with item details such as 'title', 'year', 'actors', 'director', 'genre', 'summary', etc.

    Example:
    >>> args = '{
                    "query": {
                        "match": {   
                            "title": "Joker"
                        }
                    }
                }'
    >>> results = search_item(args)
    >>> for item in results:
    ...     print(item)
    ...
    Joker (2019)
    Batman: The Killing Joke (2016) ...

    This example searches for items with the title "Joker" and returns the matching documents.
    """
    args = eval(args)
    args_origin = args.copy()
    args['size'] = 10
    if 'query' in args:
        if 'knn' in args['query']:
            args['knn'] = args['query']['knn']
            del args['query']['knn']
    
        if 'sort' in args['query']:
            args['sort'] = args['query']['sort']
            del args['query']['sort']

    if 'knn' in args:
        query_vector = es.get_embedding(args['knn']['context'])[0]['embedding']

        args['knn'] = {
                'field': 'embedding',
                'query_vector': query_vector,
                'k': n_candidate,
                'num_candidates': 5*n_candidate,
        }

    if 'query' in args and 'knn'in args and 'sort' not in args:
        args['rank'] = {'rrf': {}}
    
    try:
        results = es.search(args)
        results = [doc['_source'] for doc in results["hits"]["hits"]]

        items = []
        for doc in results:
            id = doc['id'] 
            title = doc['title']
            item = (id, title)
            items.append(item)

        return items
    
    except Exception as e:
        return []

def get_items(user_query:str, n_candidate = 10, max_iter = 3):
    user = f'Hãy tìm cho tôi:\n{user_query}'
    messages = []
    messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": user})

    items = []

    i = 0
    while i < max_iter:
        i += 1
        response = model.invoke(
            messages
        )
        messages.append({"role": "assistant", "content": response.content})
        queries = extract_dsl_queries(response.content)

        queries = [
"""
{
    "query": {
        "match": {
            "title": "Love under the Moon"
        }
    }
}
"""
        ]

        if len(queries) > 0:
            query = queries[0]
            items = search_item(args=query, n_candidate=n_candidate)
            
            if len(items) == 0:    
                user2 = (
                    "You DSL query doesn't return any item, let expand the query in a looser way, "
                    "try difference keywords, using knn and give the context of what you want to search "
                    "and write the query"
                )
                messages.append({"role": "user", "content": user2})
            else:
                break

        else:
            user2 = "You have not written the query or the query you wrote is not syntactically correct, please rewrite the query."
            messages.append({"role": "user", "content": user2})

    return items, i

df2 = pd.read_csv('../data/TV360/eval_search.csv')
df2.info()

n = int(sys.argv[2]) if len(sys.argv) > 2 else 10
n_users = int(sys.argv[1]) if len(sys.argv) > 1 else 1
n_users = min(n_users, len(df2))
n_users_real = 0

hit = {i: 0 for i in range(1, n + 1)}
ndcg = {i: 0 for i in range(1, n + 1)}

none_count = 0
sum_iter = 0

for index, row in tqdm(df2.iterrows(), total=n_users, desc='Process eval search',):
    if index == n_users:
        break

    query = row['query_search']
    label = row['search_click_id']
    
    items, iter = get_items(item=query, n_candidate=n)
    sum_iter += iter

    if len(items) == 0:
        none_count += 1
        continue

    n_users_real += 1
    for i, item in enumerate(items):
        if label == item:
            for j in range(i+1, n + 1):
                hit[j] += 1
                ndcg[j] += np.log(i + 2) / np.log(2)
            break

print('Total list count: ', n_users)
print('Real list count: ', n_users_real)
print('None list count: ', none_count)
print('avg_iter: ', sum_iter/n_users)

for i in range(1, n + 1):
    print(f'hit_rate@{i} = ', hit[i] / n_users_real if n_users_real > 0 else 0)

for i in range(1, n + 1):
    print(f'ndcg@{i} = ', ndcg[i]/ n_users_real if n_users_real > 0 else 0)
