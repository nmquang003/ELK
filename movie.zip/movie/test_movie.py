import sys
import pandas as pd
import numpy as np
from tqdm import tqdm
from Search import Search, extract_dsl_queries
from Model import model, system

index_name = 'index01'

es = Search(index_name)

# Kiểm tra index có tồn tại không
if es.es.indices.exists(index=index_name):
    if es.es.count(index=index_name)['count'] == 0:
        es.reindex('data/movie_1000.json ')
        print('Index created, number of documents: ', es.es.count(index=index_name)['count'])
    else:
        print(f"Index '{index_name}' exist.")
else:
    es.reindex('data/movie_1000.json ')
    print('Index created, number of documents: ', es.es.count(index=index_name)['count'])


def search_movie(args:str, n_candidate = 10)->list: 
    """
    Searches for movie documents in Elasticsearch using the provided args.
    This function sends a search args to Elasticsearch and returns matching movie documents.

    Parameters:
    - args (str): The search args formatted as a json. It can include fields like 'match', 'term', or 'bool' for specifying search criteria. It must be a string.

    Returns:
    - List[dict]: A list of search results from Elasticsearch. Each result is a dictionary with movie details such as 'title', 'year', 'actors', 'director', 'genre', 'summary', etc.

    Example:
    >>> args = '{
                    "query": {
                        "match": {   
                            "title": "Joker"
                        }
                    }
                }'
    >>> results = search_movie(args)
    >>> for movie in results:
    ...     print(movie)
    ...
    Joker (2019)
    Batman: The Killing Joke (2016) ...

    This example searches for movies with the title "Joker" and returns the matching documents.
    """
    args = eval(args)
    args_origin = args.copy()
    args['size'] = 10
    if 'query' in args:
        if 'knn' in args['query']:
            args['knn'] = args['query']['knn']
            del args['query']['knn']
    
        if 'sort' in args['query']:
            args['sort'] = args['query']['sort']
            del args['query']['sort']

    if 'knn' in args:
        query_vector = es.get_embedding(args['knn']['context'])[0]['embedding']

        args['knn'] = {
                'field': 'embedding',
                'query_vector': query_vector,
                'k': n_candidate,
                'num_candidates': 5*n_candidate,
        }

    if 'query' in args and 'knn'in args and 'sort' not in args:
        args['rank'] = {'rrf': {}}
    
    try:
        results = es.search(args)
        results = [doc['_source'] for doc in results["hits"]["hits"]]

        movies = []
        for doc in results:
            year = doc['year'] if doc['year'] != None else 2024
            movie = doc['title'] + f' ({year})'
            movies.append(movie)

        return movies
    
    except Exception as e:
        error_message = (
            f"Error occurred while executing search.\n"
            f"Error details: {str(e)}\n"
            f"Error args: {args_origin}"
        )
        return []

def get_movies(user:str, n_candidate = 10):
    u = f'Write a DSL query to find a movie that matches movie seeker preference based on the following conversation:\n{user}'
    messages = []
    messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": u})

    movies = []
    max_iter = 3

    i = 0
    while i < max_iter:
        i += 1
        response = model.invoke(
            messages
        )
        messages.append({"role": "assistant", "content": response.content})
        queries = extract_dsl_queries(response.content)

#         queries = [
# """
# {
#     "query": {
#         "match": {
#         "genre": "romance"
#         }
#     }
# }
# """
#         ]

        if len(queries) > 0:
            query = queries[0]
            movies = search_movie(args=query, n_candidate=n_candidate)
            
            if len(movies) == 0:    
                user2 = "You DSL query doesn't return any movie, let expand the query in a looser way, try difference keywords, knn context and write the query"
                messages.append({"role": "user", "content": user2})
            else:
                break

        else:
            user2 = "You have not written the query or the query you wrote is not syntactically correct, please rewrite the query."
            messages.append({"role": "user", "content": user2})

    return movies, i

df2 = pd.read_csv('df2.csv')
df2.info()

n = int(sys.argv[2]) if len(sys.argv) > 2 else 10
n_users = int(sys.argv[1]) if len(sys.argv) > 1 else 1
n_users = min(n_users, len(df2))
n_users_real = 0
n_users_real0 = 0
hit0 = {i: 0 for i in range(1, n + 1)}
ndcg0 = {i: 0 for i in range(1, n + 1)}
hit = {i: 0 for i in range(1, n + 1)}
ndcg = {i: 0 for i in range(1, n + 1)}

none_count = 0
sum_iter = 0

for index, row in tqdm(df2.iterrows(), total=n_users, desc='Process dialouge',):
    if index == n_users:
        break

    chat = row['historical_chat']
    label = row['movie']
    types = row['type']
    
    movies, iter = get_movies(user=chat, n_candidate=n)
    sum_iter += iter

    if len(movies) == 0:
        none_count += 1

    n_users_real += 1
    for i, movie in enumerate(movies):
        if label == movie:
            for j in range(i+1, n + 1):
                hit[j] += 1
                ndcg[j] += np.log(i + 2) / np.log(2)
            break

    if types == 0:
        n_users_real0 += 1
        for i, movie in enumerate(movies):
            if label == movie:
                for j in range(i+1, n + 1):
                    hit0[j] += 1
                    ndcg0[j] += np.log(i + 2) / np.log(2)
                break

print('Total list count: ', n_users_real)
print('None list count: ', none_count)
print('Real count: ', n_users_real)
print('Real0 count: ', n_users_real0)
print('avg_iter: ', sum_iter/n_users_real if n_users_real > 0 else 0)

for i in range(1, n + 1):
    print(f'hit_rate@{i} = ', hit[i] / n_users_real if n_users_real > 0 else 0)

for i in range(1, n + 1):
    print(f'ndcg@{i} = ', ndcg[i]/ n_users_real if n_users_real > 0 else 0)

for i in range(1, n + 1):
    print(f'hit_rate0@{i} = ', hit0[i] / n_users_real0 if n_users_real0 > 0 else 0)

for i in range(1, n + 1):
    print(f'ndcg0@{i} = ', ndcg0[i]/ n_users_real0 if n_users_real0 > 0 else 0)