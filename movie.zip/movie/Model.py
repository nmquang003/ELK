from langchain_openai import ChatOpenAI

base_path = 'http://localai:8080/v1'
model_name = 'gemma-2-9b-it'
key = '-'

model = ChatOpenAI(temperature=0, openai_api_base=base_path, openai_api_key=key, model_name=model_name, max_tokens=100)

# Example for fewshot
queries_ex = """
# 1. "Find movies that feature both Will Arnett and Katherine Heigl."
args = {
    "query": {
        "bool": {
            "must": [
                {"match": {"actors": "Will Arnett"}},
                {"match": {"actors": "Katherine Heigl"}}
            ]
        }
    },
    "knn": {
        "context": "Will Arnett and Katherine Heigl together. Can you find a movie featuring these two actors?"
    },
}

# 2. "Which movies have a box office gross of over 100 million dollars?"
args = {
    "query": {
        "range": {
            "box_office": {
                "gte": 100000000.0
            }
        }
    },
    "knn": {
        "context": "Box office hits over 100 million. Can you identify a movie that made this much money?"
    },
}

# 3. "Find movies released in 2010 that belong to the action genre."
args = {
    "query": {
        "bool": {
            "must": [
                {"match": {"year": 2010}},
                {"match": {"genre": "Action"}}
            ]
        }
    },
    "knn": {
        "context": "2010 action movies. Which action movie was released in 2010?"
    },
}

# 4. "What movies are directed by Steven Spielberg and have English as the primary language?"
args = {
    "query": {
        "bool": {
            "must": [
                {"match": {"director": "Steven Spielberg"}},
                {"match": {"language": "English"}}
            ]
        }
    },
    "knn": {
        "context": "Steven Spielberg movies in English. Can you name a movie directed by Steven Spielberg that is in English?"
    },
}

# 5. "Which movies have trailers longer than 120 seconds?"
args = {
    "query": {
        "range": {
            "trailer_duration": {
                "gt": 120.0
            }
        }
    },
    "knn": {
        "context": "Movies with trailers longer than 120 seconds. Can you find a movie with a trailer longer than 2 minutes?"
    },
}

# 6. "Find movies with a plot centered around a bank robbery."
args = {
    "query": {
        "match": {
            "long_plot": "bank robbery"
        }
    },
    "knn": {
        "context": "Movies about bank robbery. Which movie has a plot about a bank robbery?"
    },
}

# 7. "What American movies were released in 2014?"
args = {
    "query": {
        "bool": {
            "must": [
                {"match": {"country": "USA"}},
                {"match": {"year": 2014}}
            ]
        }
    },
    "knn": {
        "context": "US movies released in 2014. Can you identify an American movie released in 2014?"
    },
}

# 8. "Which movies were produced by Marvel Studios?"
args = {
    "query": {
        "match": {
            "production": "Marvel Studios"
        }
    },
    "knn": {
        "context": "Movies produced by Marvel Studios. Can you find a movie produced by Marvel Studios?"
    },
}

# 9. "I want to watch the highest-rated movie on IMDb."
args = {
    "query": {
        "match_all": {}
    },
    "sort": {
        "rating.Internet Movie Database": "desc"
    },
    "knn": {
        "context": "Highest rated movies on IMDb. What is the highest-rated movie on IMDb?"
    },
}

# 10. "Which movies have the most trailer views on YouTube?"
args = {
    "query": {
        "match_all": {}
    },
    "sort": {
        "youtube_view": "desc"
    },
    "knn": {
        "context": "Movies with the most YouTube trailer views. Can you find the movie with the highest trailer views on YouTube?"
    },
}

# 11. "Find movies with posters on Amazon."
args = {
    "query": {
        "match": {
            "poster": "amazon.com"
        }
    },
    "knn": {
        "context": "Movies with posters hosted on Amazon. Can you find a movie with a poster on Amazon?"
    },
}

# 12. "What movies are in the comedy genre but also have crime elements?"
args = {
    "query": {
        "bool": {
            "must": [
                {"match": {"genre": "Comedy"}},
                {"match": {"long_plot": "crime"}}
            ]
        }
    },
    "knn": {
        "context": "Comedy movies with crime elements. Can you identify a comedy movie that also involves crime?"
    },
}
"""

fields_ex = """
    Field: actors, Type: text, Description: Lists the main actors involved in the movie, represented as an array of strings.
    Field: awards, Type: text, Description: Contains information on any awards the movie has won or been nominated for.
    Field: box_office, Type: text, Description: Represents the box office earnings of the movie, typically including the gross revenue earned from theaters.
    Field: country, Type: text, Description: Specifies the countries where the movie was produced, often listed as a comma-separated string.
    Field: director, Type: text, Description: The name of the director(s) of the movie. If the movie has multiple directors, they are listed as a comma-separated string.
    Field: dvd_release, Type: date, Description: The official release date of the movie on DVD, formatted as a date string.
    Field: embedding, Type: dense_vector, Description: A dense vector representation of the movie used for similarity calculations or machine learning purposes.
    Field: genre, Type: text, Description: Describes the genre(s) of the movie, such as 'Action', 'Comedy', or 'Drama'. Multiple genres are often listed as a comma-separated string.
    Field: imdb_id, Type: text, Description: The unique identifier for the movie on IMDb, often used as a reference or key for retrieving more detailed information.
    Field: imdb_type, Type: text, Description: Indicates the type of content on IMDb, such as 'movie', 'series', or 'documentary'.
    Field: language, Type: text, Description: Lists the primary languages spoken in the movie, often as a comma-separated string.
    Field: long_plot, Type: text, Description: Provides a detailed synopsis of the movie’s plot, capturing more nuances and subplots.
    Field: movie_runtime, Type: text, Description: The total runtime of the movie, often expressed in minutes, e.g., '85 min'.
    Field: poster, Type: text, Description: The URL of the movie's poster image, typically linking to an online image.
    Field: production, Type: text, Description: The name of the production company or companies that produced the movie.
    Field: rated, Type: text, Description: The movie’s content rating, such as 'PG', 'R', or 'G', indicating the appropriate audience.
    Field: rating.Internet Movie Database, Type: float, Description: The specific rating value from IMDb, represented as a float.
    Field: release_date, Type: date, Description: The official release date of the movie in theaters, formatted as a date string.
    Field: short_plot, Type: text, Description: A brief summary of the movie’s plot, capturing the essential storyline in a few sentences.
    Field: summary, Type: text, Description: A concise overview of key movie details including title, year, country, actors, awards, director, genre, runtime, and plot.
    Field: title, Type: text, Description: The official title of the movie.
    Field: trailer_duration, Type: float, Description: The duration of the movie’s trailer, represented in seconds.
    Field: video_id, Type: text, Description: The unique identifier for the movie's trailer on platforms like YouTube, often part of the video’s URL.
    Field: writer, Type: text, Description: Names of the writers who contributed to the movie’s script, listed as a comma-separated string.
    Field: year, Type: long, Description: The year the movie was released.
    Field: youtube_comment, Type: float, Description: The total number of comments on the movie’s trailer video on YouTube.
    Field: youtube_dislike, Type: float, Description: The total number of dislikes the movie’s trailer has received on YouTube.
    Field: youtube_favorite, Type: float, Description: The number of times the trailer has been favorited on YouTube, though this metric is rarely used.
    Field: youtube_like, Type: float, Description: The total number of likes the movie’s trailer has received on YouTube.
    Field: youtube_link, Type: text, Description: The URL link to the movie’s trailer on YouTube.
    Field: youtube_view, Type: float, Description: The total number of views the movie’s trailer has accumulated on YouTube.
"""

system = f"""
    You are a helpful movie recommender. Based on the dialogue given after between a recommender
    and a movie seeker. Then you need to call search_movie tool with appropriate parameters to 
    get a list of movies that match movie seeker preferences.
    Search_movie is a tool to search movie in database, call the tool: search_movie(args), 
    where args is an elasticsearch query in json format, for example:
    {queries_ex}

    Pay attention to the syntax DSL query.

    These are the information fields of each movie on elasticsearch:
    {fields_ex}

    When calling the tool, the fields you use must match the keywords above.
    If you use the wrong keywords, you will not get results. Please pay attention

    You answer just contain the DSL Query.  
"""